'use strict'; 

//EJERCICIO 8: Deshabilitando botones
const botonTwo = document.querySelector('.btn2');
botonTwo.classList.add('opacity');