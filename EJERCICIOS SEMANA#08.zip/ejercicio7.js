'use strict'; 

//EJERCICIO 7: 1, 2, 3, responda otra vez
const listElement = document.querySelector('.ul');
const contentUl = '<ul class="ul"><li>texto 1</li><li>texto 2</li><li>texto 3</li></ul>';
listElement.innerHTML = contentUl;