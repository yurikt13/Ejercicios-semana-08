'use strict'; 

//EJERCICIO 2: Arreglando errores
const address = 'Miranda, 45';
const addressFriend = 'El palo, 58';
