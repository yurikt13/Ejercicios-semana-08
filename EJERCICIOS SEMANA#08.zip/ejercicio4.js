'use strict'; 

//EJERCICIO 4: Seleccionando Geek Girl
const title = document.querySelector('.title');
const content = '<li class="girl1">Yuri Monroy</li>';
title.innerHTML = title.innerHTML + content;
