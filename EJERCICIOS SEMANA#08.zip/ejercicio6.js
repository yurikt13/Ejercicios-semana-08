'use strict'; 

//EJERCICIO 6: Lorem ipsum
const divElement = document.querySelector('.div');
const contentDiv = '<div class="div"><h1>Lorem ipsum</h1> <img src="http://via.placeholder.com/350x150"></img><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p></div>'
divElement.innerHTML = contentDiv;
