'use strict'; 

//EJERCICIO 3: Hola Mundo
const textElement = document.querySelector('.text');
textElement.innerHTML = textElement.innerHTML + ' Mundo';
