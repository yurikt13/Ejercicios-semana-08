'use strict'; 

//EJERCICIO 4: Seleccionando Geek Girl
var passwordElement = document.querySelector('.password');
passwordElement.innerHTML = '**';